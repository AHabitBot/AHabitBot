from backend.database.database import get_pool


# =========================================================
# ИЗМЕНИТЬ ЯЗЫК ПОЛЬЗОВАТЕЛЯ
# =========================================================

async def set_user_language(
    user_id: int,
    language: str,
) -> dict:
    """
    Сохраняет язык интерфейса пользователя.
    Допустимые значения проверяются на уровне API.
    """

    pool = await get_pool()

    async with pool.acquire() as connection:

        row = await connection.fetchrow(
            """
            INSERT INTO user_settings (
                user_id,
                language
            )
            VALUES (
                $1,
                $2
            )

            ON CONFLICT (user_id)
            DO UPDATE SET
                language = EXCLUDED.language,
                updated_at = NOW()

            RETURNING
                user_id,
                timezone,
                language,
                reminders_enabled,
                last_reminder_date
            """,
            user_id,
            language,
        )

    return {
        "user_id": int(
            row["user_id"]
        ),

        "timezone":
            row["timezone"]
            or "Europe/Kyiv",

        "language":
            row["language"]
            or "ru",

        "reminders_enabled":
            bool(
                row["reminders_enabled"]
            ),

        "last_reminder_date":
            (
                row["last_reminder_date"].isoformat()
                if row["last_reminder_date"]
                else None
            ),
    }
