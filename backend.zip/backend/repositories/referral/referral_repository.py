from backend.services.leaderboard.league_lock import lock_league_week
from backend.repositories.leaderboard.weekly_xp_repository import refresh_user_weekly_xp
import asyncpg

from backend.database.database import get_connection
# ============================================================================
# Создание реферальной связи
# ============================================================================

async def create_referral(
    inviter_user_id: int,
    invited_user_id: int,
    xp_amount: int = 5,
) -> asyncpg.Record | None:
    """
    Создаёт реферальную связь и начисляет XP пригласившему.

    XP начисляется:
    - в общий user_stats.total_xp;
    - в недельный рейтинг после запуска соревнования.

    Один invited_user_id может существовать
    в таблице referrals только один раз.
    """

    # ------------------------------------------------------------------------
    # Защита от самоприглашения.
    # ------------------------------------------------------------------------

    if inviter_user_id == invited_user_id:
        return None

    # ------------------------------------------------------------------------
    # Недельный период определяется сервисом рейтинга.
    # ------------------------------------------------------------------------


    async with get_connection() as connection:
        async with connection.transaction():
            await lock_league_week(connection)


            # ----------------------------------------------------------------
            # Создаём реферальную связь.
            #
            # UNIQUE(invited_user_id) + ON CONFLICT DO NOTHING
            # гарантируют, что за одного приглашённого
            # XP нельзя начислить повторно.
            # ----------------------------------------------------------------

            referral = await connection.fetchrow(
                """
                INSERT INTO referrals (
                    inviter_user_id,
                    invited_user_id,
                    xp_awarded,
                    xp_amount,
                    created_at
                )
                VALUES (
                    $1,
                    $2,
                    TRUE,
                    $3,
                    clock_timestamp()
                )

                ON CONFLICT (invited_user_id)
                DO NOTHING

                RETURNING
                    id,
                    inviter_user_id,
                    invited_user_id,
                    xp_awarded,
                    xp_amount,
                    created_at
                """,
                inviter_user_id,
                invited_user_id,
                xp_amount,
            )

            if referral is None:
                return None

            # ----------------------------------------------------------------
            # Начисляем XP в общую статистику пользователя.
            # ----------------------------------------------------------------

            await connection.execute(
                """
                INSERT INTO user_stats (
                    user_id,
                    total_xp
                )
                VALUES (
                    $1,
                    $2
                )

                ON CONFLICT (user_id)
                DO UPDATE SET
                    total_xp =
                        user_stats.total_xp
                        + EXCLUDED.total_xp,

                    updated_at = NOW()
                """,
                inviter_user_id,
                xp_amount,
            )

            await refresh_user_weekly_xp(connection, inviter_user_id, at=referral["created_at"])

            return referral


# ============================================================================
# Проверка существования приглашения
# ============================================================================

async def get_referral_by_invited_user_id(
    invited_user_id: int,
) -> asyncpg.Record | None:
    async with get_connection() as connection:
        return await connection.fetchrow(
            """
            SELECT
                id,
                inviter_user_id,
                invited_user_id,
                xp_awarded,
                xp_amount,
                created_at
            FROM referrals
            WHERE invited_user_id = $1
            """,
            invited_user_id,
        )


# ============================================================================
# Статистика приглашений
# ============================================================================

async def get_referral_stats(
    inviter_user_id: int,
) -> asyncpg.Record:
    async with get_connection() as connection:
        return await connection.fetchrow(
            """
            SELECT
                COUNT(*)::INTEGER AS invited_count,

                COALESCE(
                    SUM(
                        CASE
                            WHEN xp_awarded = TRUE
                            THEN xp_amount
                            ELSE 0
                        END
                    ),
                    0
                )::NUMERIC(12,2) AS earned_xp

            FROM referrals
            WHERE inviter_user_id = $1
            """,
            inviter_user_id,
        )