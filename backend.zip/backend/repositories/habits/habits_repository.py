from backend.services.leaderboard.league_lock import lock_league_week
from backend.repositories.leaderboard.weekly_xp_repository import refresh_user_weekly_xp
from datetime import date, datetime, timedelta
import secrets
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from backend.database.database import get_connection
from backend.repositories.habits.shared_habits_repository import (
    get_shared_contexts_for_habits,
    get_shared_streak_states_for_habits,
    get_friends_streak_state,
    update_friends_streak_for_users,
)
from backend.services.habits.repeat_rules import (
    calculate_repeat_streak,
    calculate_user_streak_state,
    is_confirmation_allowed,
)

DAILY_XP_CONFIRMATIONS_LIMIT = 3
DEFAULT_TIMEZONE = "Europe/Kyiv"


# =========================================================
# ПОЛУЧИТЬ ПРИВЫЧКИ ПОЛЬЗОВАТЕЛЯ
# =========================================================

async def get_user_habits(
    user_id: int,
) -> dict[str, Any]:
    async with get_connection() as connection:
        # -------------------------------------------------
        # Получаем часовой пояс пользователя.
        # -------------------------------------------------

        timezone_name = await connection.fetchval(
            """
            SELECT timezone
            FROM user_settings
            WHERE user_id = $1
            """,
            user_id,
        )

        today = get_user_local_date(
            timezone_name
        )

        week_start = today - timedelta(
            days=today.weekday()
        )

        week_end = week_start + timedelta(
            days=6
        )

        # -------------------------------------------------
        # Получаем все активные привычки пользователя.
        #
        # Отдельно присоединяем подтверждение за сегодня,
        # чтобы сразу вернуть completed_today.
        # -------------------------------------------------

        habit_rows = await connection.fetch(
            """
            SELECT
                h.id,
                h.user_id,
                h.title,
                h.description,
                h.emoji,
                h.color,
                h.size,
                h.xp_reward,
                h.is_archived,
                h.habit_type,
                h.created_at,
                h.updated_at,
                h.repeat_type,
                h.repeat_days,
                h.weekly_target,
                h.challenge_target,
                h.repeat_started_on,
                h.habit_reminder,
                h.invite_token,

                COALESCE(
                    today_confirmation.is_confirmed,
                    FALSE
                ) AS completed_today,

                COALESCE(
                    today_confirmation.xp_awarded,
                    FALSE
                ) AS xp_awarded_today,

                COALESCE(
                    today_confirmation.xp_amount,
                    0
                ) AS xp_amount_today

            FROM habits AS h

            LEFT JOIN habit_confirmations
                AS today_confirmation
                ON today_confirmation.habit_id = h.id
                AND today_confirmation.confirmation_date = $2

            WHERE h.user_id = $1
              AND h.is_archived = FALSE

            ORDER BY
                h.created_at ASC,
                h.id ASC
            """,
            user_id,
            today,
        )

        # -------------------------------------------------
        # Получаем подтверждения текущей недели.
        #
        # Пока сохраняем текущую рабочую логику
        # week_progress.
        # -------------------------------------------------

        week_rows = await connection.fetch(
            """
            SELECT
                hc.habit_id,
                hc.confirmation_date

            FROM habit_confirmations AS hc

            INNER JOIN habits AS h
                ON h.id = hc.habit_id

            WHERE h.user_id = $1
              AND h.is_archived = FALSE
              AND hc.confirmation_date
                  BETWEEN $2 AND $3
              AND hc.is_confirmed = TRUE

            ORDER BY
                hc.confirmation_date ASC
            """,
            user_id,
            week_start,
            week_end,
        )

        # -------------------------------------------------
        # Получаем всю историю подтверждённых дат
        # каждой активной привычки пользователя.
        #
        # Эти даты будут использоваться:
        # - календарём;
        # - серией конкретной привычки;
        # - недельным прогрессом.
        # -------------------------------------------------

        completed_dates_rows = await connection.fetch(
            """
            SELECT
                hc.habit_id,
                hc.confirmation_date

            FROM habit_confirmations AS hc

            INNER JOIN habits AS h
                ON h.id = hc.habit_id

            WHERE h.user_id = $1
              AND h.is_archived = FALSE
              AND hc.is_confirmed = TRUE

            ORDER BY
                hc.habit_id ASC,
                hc.confirmation_date ASC
            """,
            user_id,
        )

        # -------------------------------------------------
        # Общую статистику пока только читаем.
        #
        # На этом этапе общий current_streak
        # и max_streak не пересчитываем.
        # -------------------------------------------------

        statistics = await connection.fetchrow(
            """
            SELECT
                current_streak,
                max_streak,
                friends_streak,
                friends_max_streak,
                total_confirmations,
                total_xp
            FROM user_stats
            WHERE user_id = $1
            """,
            user_id,
        )

    # =====================================================
    # СОБИРАЕМ НЕДЕЛЬНЫЙ ПРОГРЕСС
    # =====================================================

    week_progress_by_habit: dict[
        int,
        list[bool],
    ] = {}

    for row in habit_rows:
        week_progress_by_habit[
            row["id"]
        ] = [
            False,
            False,
            False,
            False,
            False,
            False,
            False,
        ]

    for row in week_rows:
        habit_id = row["habit_id"]

        day_index = (
            row["confirmation_date"]
            - week_start
        ).days

        if (
            habit_id
            in week_progress_by_habit
            and 0 <= day_index <= 6
        ):
            week_progress_by_habit[
                habit_id
            ][day_index] = True

    # =====================================================
    # СОБИРАЕМ COMPLETED DATES
    # =====================================================

    completed_dates_by_habit: dict[
        int,
        list[date],
    ] = {}

    for row in habit_rows:
        completed_dates_by_habit[
            row["id"]
        ] = []

    for row in completed_dates_rows:
        habit_id = row["habit_id"]

        if (
            habit_id
            not in completed_dates_by_habit
        ):
            continue

        completed_dates_by_habit[
            habit_id
        ].append(
            row["confirmation_date"]
        )

    shared_contexts = await get_shared_contexts_for_habits(
        habit_ids=[int(row["id"]) for row in habit_rows],
        today=today,
    )
    shared_streak_states = await get_shared_streak_states_for_habits(
        habit_ids=[int(row["id"]) for row in habit_rows],
        today=today,
    )

    # =====================================================
    # ФОРМИРУЕМ ФИНАЛЬНЫЙ СПИСОК ПРИВЫЧЕК
    # =====================================================

    habits = []

    for row in habit_rows:
        habit = dict(row)

        habit["week_progress"] = (
            week_progress_by_habit.get(
                row["id"],
                [
                    False,
                    False,
                    False,
                    False,
                    False,
                    False,
                    False,
                ],
            )
        )

        habit_completed_dates = (
            completed_dates_by_habit.get(
                row["id"],
                [],
            )
        )

        habit["completed_dates"] = [
            completed_date.isoformat()
            for completed_date
            in habit_completed_dates
        ]

        habit["streak"] = calculate_repeat_streak(
                habit["repeat_type"], list(habit["repeat_days"] or []),
                habit_completed_dates, today, habit["repeat_started_on"],
            )
        habit["confirmation_allowed_today"] = is_confirmation_allowed(
            habit["repeat_type"], list(habit["repeat_days"] or []), today,
        )

        habit["max_streak"] = (
            calculate_habit_max_streak(
                completed_dates=
                    habit_completed_dates,
            )
        )

        habit["completed_count"] = len(
            habit_completed_dates
        )

        shared_context = shared_contexts.get(int(row["id"]))
        shared_streak_state = shared_streak_states.get(int(row["id"]))
        if shared_streak_state:
            habit["streak"] = int(shared_streak_state["streak"])
            habit["streak_frozen"] = bool(shared_streak_state["frozen"])
        else:
            from backend.services.habits.repeat_rules import calculate_repeat_streak_state
            _, habit_frozen = calculate_repeat_streak_state(
                habit["repeat_type"], list(habit["repeat_days"] or []),
                habit_completed_dates, today, habit["repeat_started_on"],
            )
            habit["streak_frozen"] = habit_frozen

        shared_context = shared_contexts.get(int(row["id"]))
        habit["shared"] = (
            {
                **shared_context,
                "is_owner": int(shared_context["owner_user_id"]) == int(user_id),
            }
            if shared_context
            else None
        )

        habits.append(habit)

    return {
        "habits": habits,

        "statistics": {
            "current_streak": (
                statistics["current_streak"]
                if statistics
                else 0
            ),
            "max_streak": (
                statistics["max_streak"]
                if statistics
                else 0
            ),
            "friends_streak": (
                statistics["friends_streak"]
                if statistics
                else 0
            ),
            "friends_max_streak": (
                statistics["friends_max_streak"]
                if statistics
                else 0
            ),
            "friends_streak_frozen": bool(
                (await get_friends_streak_state(user_id, today))["frozen"]
            ),
            "total_confirmations": (
                statistics[
                    "total_confirmations"
                ]
                if statistics
                else 0
            ),
            "total_xp": (
                statistics["total_xp"]
                if statistics
                else 0
            ),
        },
    }


# =========================================================
# СОЗДАТЬ ПРИВЫЧКУ
# =========================================================

async def create_habit(
    user_id: int,
    title: str,
    description: str | None,
    emoji: str,
    color: str,
    size: str,
    repeat_type: str,
    repeat_days: list[int],
    weekly_target: int | None,
    challenge_target: int | None,
    habit_reminder: str | None,
) -> dict[str, Any]:
    invite_token = secrets.token_urlsafe(24)

    async with get_connection() as connection:
        row = await connection.fetchrow(
            """
            INSERT INTO habits (
                user_id,
                title,
                description,
                emoji,
                color,
                size,
                repeat_type,
                repeat_days,
                weekly_target,
                challenge_target,
                repeat_started_on,
                habit_reminder,
                invite_token
            )
            VALUES ($1, $2, $13, $3, $4, $5, $6, $7, $8, $9, $10, $11::TIME, $12)
            RETURNING
                id,
                user_id,
                title,
                description,
                emoji,
                color,
                size,
                xp_reward,
                is_archived,
                created_at,
                updated_at
                , repeat_type, repeat_days, weekly_target, challenge_target, repeat_started_on, habit_reminder, invite_token
            """,
            user_id,
            title,
            emoji,
            color,
            size,
            repeat_type,
            repeat_days,
            weekly_target,
            challenge_target,
            get_user_local_date(await connection.fetchval(
                "SELECT timezone FROM user_settings WHERE user_id = $1", user_id
            )),
            habit_reminder,
            invite_token,
            description,
        )

    if row is None:
        raise RuntimeError(
            "Не удалось создать привычку"
        )

    return dict(row)


# =========================================================
# ОБНОВИТЬ ПРИВЫЧКУ
# =========================================================

async def update_habit(
    user_id: int,
    habit_id: int,
    title: str,
    description: str | None,
    emoji: str,
    color: str,
    size: str,
    repeat_type: str,
    repeat_days: list[int],
    weekly_target: int | None,
    challenge_target: int | None,
    habit_reminder: str | None,
) -> dict[str, Any] | None:
    """
    Обычная привычка обновляется как раньше.

    В совместной привычке:
    - владелец синхронизирует общие параметры всем;
    - обычный участник меняет только своё напоминание;
    - напоминания других участников никогда не меняются.
    """

    async with get_connection() as connection:
        async with connection.transaction():
            current = await connection.fetchrow(
                """
                SELECT
                    h.*,
                    shm.shared_habit_id,
                    sh.owner_user_id
                FROM habits AS h
                LEFT JOIN shared_habit_members AS shm
                    ON shm.habit_id = h.id
                LEFT JOIN shared_habits AS sh
                    ON sh.id = shm.shared_habit_id
                WHERE h.id = $1
                  AND h.user_id = $2
                  AND h.is_archived = FALSE
                  AND h.habit_type = 'regular'
                FOR UPDATE OF h
                """,
                habit_id,
                user_id,
            )

            if current is None:
                return None

            shared_habit_id = current["shared_habit_id"]
            is_shared = shared_habit_id is not None
            is_owner = (
                is_shared
                and int(current["owner_user_id"]) == int(user_id)
            )

            # Участник совместной привычки:
            # общие поля менять не может.
            if is_shared and not is_owner:
                row = await connection.fetchrow(
                    """
                    UPDATE habits
                    SET
                        habit_reminder = $3::TIME,
                        habit_reminder_last_sent_date = CASE
                            WHEN habit_reminder
                                IS DISTINCT FROM $3::TIME
                            THEN NULL
                            ELSE habit_reminder_last_sent_date
                        END,
                        updated_at = NOW()
                    WHERE id = $1
                      AND user_id = $2
                      AND is_archived = FALSE
                    RETURNING
                        id, user_id, title, description, emoji, color, size,
                        xp_reward, is_archived, created_at, updated_at,
                        repeat_type, repeat_days, weekly_target,
                        challenge_target, repeat_started_on,
                        habit_reminder, invite_token
                    """,
                    habit_id,
                    user_id,
                    habit_reminder,
                )
                return dict(row) if row else None

            if current["repeat_type"] == "challenge":
                if repeat_type != "challenge":
                    raise ValueError(
                        "Начатый челлендж нельзя изменить на другой режим"
                    )
                if int(challenge_target or 0) < int(
                    current["challenge_target"] or 0
                ):
                    raise ValueError(
                        "Количество дней челленджа можно только увеличивать"
                    )

            timezone_name = await connection.fetchval(
                """
                SELECT timezone
                FROM user_settings
                WHERE user_id = $1
                """,
                user_id,
            )

            rule_changed = (
                current["repeat_type"] != repeat_type
                or (
                    repeat_type == "challenge"
                    and int(challenge_target or 0)
                    != int(current["challenge_target"] or 0)
                )
            )

            new_repeat_started_on = (
                get_user_local_date(timezone_name)
                if (
                    rule_changed
                    and current["repeat_type"] != "challenge"
                )
                else current["repeat_started_on"]
            )

            # Владелец: общие параметры обновляются
            # во всех связанных habits.
            if is_owner:
                await connection.execute(
                    """
                    UPDATE habits AS h
                    SET
                        title = $2,
                        description = $11,
                        emoji = $3,
                        color = $4,
                        size = $5,
                        repeat_type = $6,
                        repeat_days = $7,
                        weekly_target = $8,
                        challenge_target = $9,
                        repeat_started_on = $10,
                        updated_at = NOW()
                    FROM shared_habit_members AS shm
                    WHERE shm.shared_habit_id = $1
                      AND h.id = shm.habit_id
                      AND h.is_archived = FALSE
                    """,
                    shared_habit_id,
                    title,
                    emoji,
                    color,
                    size,
                    repeat_type,
                    repeat_days,
                    weekly_target,
                    challenge_target,
                    new_repeat_started_on,
                    description,
                )

                # Напоминание владельца остаётся персональным.
                row = await connection.fetchrow(
                    """
                    UPDATE habits
                    SET
                        habit_reminder = $3::TIME,
                        habit_reminder_last_sent_date = CASE
                            WHEN habit_reminder
                                IS DISTINCT FROM $3::TIME
                            THEN NULL
                            ELSE habit_reminder_last_sent_date
                        END,
                        updated_at = NOW()
                    WHERE id = $1
                      AND user_id = $2
                      AND is_archived = FALSE
                    RETURNING
                        id, user_id, title, description, emoji, color, size,
                        xp_reward, is_archived, created_at, updated_at,
                        repeat_type, repeat_days, weekly_target,
                        challenge_target, repeat_started_on,
                        habit_reminder, invite_token
                    """,
                    habit_id,
                    user_id,
                    habit_reminder,
                )
                return dict(row) if row else None

            # Обычная привычка.
            row = await connection.fetchrow(
                """
                UPDATE habits
                SET
                    title = $3,
                    description = $13,
                    emoji = $4,
                    color = $5,
                    size = $6,
                    repeat_type = $7,
                    repeat_days = $8,
                    weekly_target = $9,
                    challenge_target = $10,
                    repeat_started_on = $11,
                    habit_reminder = $12::TIME,
                    habit_reminder_last_sent_date = CASE
                        WHEN habit_reminder
                            IS DISTINCT FROM $12::TIME
                        THEN NULL
                        ELSE habit_reminder_last_sent_date
                    END,
                    updated_at = NOW()
                WHERE id = $1
                  AND user_id = $2
                  AND is_archived = FALSE
                RETURNING
                    id, user_id, title, description, emoji, color, size,
                    xp_reward, is_archived, created_at, updated_at,
                    repeat_type, repeat_days, weekly_target,
                    challenge_target, repeat_started_on,
                    habit_reminder, invite_token
                """,
                habit_id,
                user_id,
                title,
                emoji,
                color,
                size,
                repeat_type,
                repeat_days,
                weekly_target,
                challenge_target,
                new_repeat_started_on,
                habit_reminder,
                description,
            )
            return dict(row) if row else None


# =========================================================
# АРХИВИРОВАТЬ ПРИВЫЧКУ
# =========================================================

async def archive_habit(
    user_id: int,
    habit_id: int,
) -> bool:
    """
    Перемещает активную привычку пользователя в архив.

    При архивации:
    - привычка становится архивной;
    - сохраняется точное время архивации;
    - история подтверждений не удаляется.

    Возвращает:
        True  — привычка успешно архивирована.
        False — привычка не найдена,
                принадлежит другому пользователю
                или уже находится в архиве.
    """

    async with get_connection() as connection:
        result = await connection.execute(
            """
            UPDATE habits
            SET
                is_archived = TRUE,
                archived_at = NOW(),
                updated_at = NOW()
            WHERE id = $1
              AND user_id = $2
              AND is_archived = FALSE
              AND habit_type = 'regular'
            """,
            habit_id,
            user_id,
        )

    return result == "UPDATE 1"



# =========================================================
# ПОЛУЧИТЬ АРХИВНЫЕ ПРИВЫЧКИ ПОЛЬЗОВАТЕЛЯ
# =========================================================

async def get_archived_habits(
    user_id: int,
) -> list[dict[str, Any]]:
    """
    Возвращает архивные привычки пользователя.

    Для каждой привычки возвращаем:
    - основные данные привычки;
    - дату архивации;
    - количество подтверждений;
    - максимальную серию за всю историю.

    Активные привычки сюда не попадают.
    """

    async with get_connection() as connection:
        # -------------------------------------------------
        # Получаем сами архивные привычки.
        # -------------------------------------------------

        habit_rows = await connection.fetch(
            """
            SELECT
                h.id,
                h.user_id,
                h.title,
                h.emoji,
                h.color,
                h.size,
                h.xp_reward,
                h.is_archived,
                h.archived_at,
                h.created_at,
                h.updated_at
                , h.repeat_type, h.repeat_days, h.weekly_target, h.challenge_target, h.repeat_started_on

            FROM habits AS h

            WHERE h.user_id = $1
              AND h.is_archived = TRUE

            ORDER BY
                h.archived_at DESC NULLS LAST,
                h.updated_at DESC,
                h.id DESC
            """,
            user_id,
        )

        if not habit_rows:
            return []

        # -------------------------------------------------
        # Получаем всю историю подтверждений
        # только архивных привычек пользователя.
        #
        # Историю не удаляем и не меняем.
        # Она нужна для:
        # - общего количества подтверждений;
        # - максимальной серии.
        # -------------------------------------------------

        confirmation_rows = await connection.fetch(
            """
            SELECT
                hc.habit_id,
                hc.confirmation_date

            FROM habit_confirmations AS hc

            INNER JOIN habits AS h
                ON h.id = hc.habit_id

            WHERE h.user_id = $1
              AND h.is_archived = TRUE
              AND hc.is_confirmed = TRUE

            ORDER BY
                hc.habit_id ASC,
                hc.confirmation_date ASC
            """,
            user_id,
        )

    # =====================================================
    # СОБИРАЕМ ДАТЫ ПОДТВЕРЖДЕНИЙ ПО ПРИВЫЧКАМ
    # =====================================================

    completed_dates_by_habit: dict[
        int,
        list[date],
    ] = {}

    for row in habit_rows:
        completed_dates_by_habit[
            row["id"]
        ] = []

    for row in confirmation_rows:
        habit_id = row["habit_id"]

        if (
            habit_id
            not in completed_dates_by_habit
        ):
            continue

        completed_dates_by_habit[
            habit_id
        ].append(
            row["confirmation_date"]
        )

    # =====================================================
    # ФОРМИРУЕМ АРХИВ
    # =====================================================

    archived_habits: list[
        dict[str, Any]
    ] = []

    for row in habit_rows:
        habit = dict(row)

        completed_dates = (
            completed_dates_by_habit.get(
                row["id"],
                [],
            )
        )

        habit["completed_count"] = len(
            completed_dates
        )

        habit["max_streak"] = (
            calculate_habit_max_streak(
                completed_dates=
                    completed_dates,
            )
        )

        archived_habits.append(
            habit
        )

    return archived_habits


# =========================================================
# ВОССТАНОВИТЬ ПРИВЫЧКУ ИЗ АРХИВА
# =========================================================

async def restore_habit(
    user_id: int,
    habit_id: int,
) -> dict[str, Any] | None:
    """
    Восстанавливает архивную привычку пользователя
    и сразу возвращает её полное актуальное состояние.

    После восстановления frontend получает:
    - основные данные привычки;
    - completed_today;
    - xp_awarded_today;
    - xp_amount_today;
    - completed_dates;
    - streak;
    - max_streak;
    - completed_count;
    - week_progress.

    Дополнительный GET /api/habits не требуется.
    """

    async with get_connection() as connection:
        async with connection.transaction():

            # -------------------------------------------------
            # Часовой пояс пользователя
            # -------------------------------------------------

            timezone_name = await connection.fetchval(
                """
                SELECT timezone
                FROM user_settings
                WHERE user_id = $1
                """,
                user_id,
            )

            today = get_user_local_date(
                timezone_name
            )

            week_start = (
                today
                - timedelta(
                    days=today.weekday()
                )
            )

            # -------------------------------------------------
            # Восстанавливаем привычку
            # -------------------------------------------------

            row = await connection.fetchrow(
                """
                UPDATE habits
                SET
                    is_archived = FALSE,
                    archived_at = NULL,
                    updated_at = NOW()

                WHERE id = $1
                  AND user_id = $2
                  AND is_archived = TRUE
                  AND habit_type = 'regular'

                RETURNING
                    id,
                    user_id,
                    title,
                    emoji,
                    color,
                    size,
                    xp_reward,
                    is_archived,
                    archived_at,
                    created_at,
                    updated_at
                    , repeat_type, repeat_days, weekly_target, challenge_target, repeat_started_on
                """,
                habit_id,
                user_id,
            )

            if row is None:
                return None

            # -------------------------------------------------
            # Подтверждение за сегодня
            # -------------------------------------------------

            today_confirmation = (
                await connection.fetchrow(
                    """
                    SELECT
                        is_confirmed,
                        xp_awarded,
                        xp_amount

                    FROM habit_confirmations

                    WHERE habit_id = $1
                      AND confirmation_date = $2
                    """,
                    habit_id,
                    today,
                )
            )

            completed_today = bool(
                today_confirmation
                and today_confirmation[
                    "is_confirmed"
                ]
            )

            xp_awarded_today = bool(
                today_confirmation
                and today_confirmation[
                    "is_confirmed"
                ]
                and today_confirmation[
                    "xp_awarded"
                ]
            )

            xp_amount_today = (
                int(
                    today_confirmation[
                        "xp_amount"
                    ]
                )
                if xp_awarded_today
                else 0
            )

            # -------------------------------------------------
            # Вся история подтверждений привычки
            # -------------------------------------------------

            completed_date_rows = (
                await connection.fetch(
                    """
                    SELECT
                        confirmation_date

                    FROM habit_confirmations

                    WHERE habit_id = $1
                      AND is_confirmed = TRUE

                    ORDER BY
                        confirmation_date ASC
                    """,
                    habit_id,
                )
            )

            completed_dates = [
                item["confirmation_date"]
                for item in completed_date_rows
            ]

            # -------------------------------------------------
            # Текущая серия
            # -------------------------------------------------

            streak = calculate_repeat_streak(
                    row["repeat_type"], list(row["repeat_days"] or []),
                    completed_dates, today, row["repeat_started_on"],
                )

            # -------------------------------------------------
            # Лучшая серия
            # -------------------------------------------------

            max_streak = (
                calculate_habit_max_streak(
                    completed_dates=
                        completed_dates,
                )
            )

            # -------------------------------------------------
            # Количество подтверждений
            # -------------------------------------------------

            completed_count = len(
                completed_dates
            )

            # -------------------------------------------------
            # Прогресс текущей недели
            # -------------------------------------------------

            week_progress = [
                False,
                False,
                False,
                False,
                False,
                False,
                False,
            ]

            for completed_date in completed_dates:
                day_index = (
                    completed_date
                    - week_start
                ).days

                if 0 <= day_index <= 6:
                    week_progress[
                        day_index
                    ] = True

            # -------------------------------------------------
            # Финальный объект привычки
            # -------------------------------------------------

            habit = dict(row)

            habit[
                "completed_today"
            ] = completed_today

            habit[
                "xp_awarded_today"
            ] = xp_awarded_today

            habit[
                "xp_amount_today"
            ] = xp_amount_today

            habit[
                "completed_dates"
            ] = [
                completed_date.isoformat()
                for completed_date
                in completed_dates
            ]

            habit[
                "streak"
            ] = streak

            habit[
                "max_streak"
            ] = max_streak

            habit[
                "completed_count"
            ] = completed_count

            habit[
                "week_progress"
            ] = week_progress

            habit["confirmation_allowed_today"] = is_confirmation_allowed(
                row["repeat_type"], list(row["repeat_days"] or []), today
            )

            return habit



# =========================================================
# ПОЛУЧИТЬ ЛОКАЛЬНУЮ ДАТУ ПОЛЬЗОВАТЕЛЯ
# =========================================================

def get_user_local_date(
    timezone_name: str | None,
):
    safe_timezone = (
        timezone_name
        or DEFAULT_TIMEZONE
    )

    try:
        timezone = ZoneInfo(
            safe_timezone
        )
    except ZoneInfoNotFoundError:
        timezone = ZoneInfo(
            DEFAULT_TIMEZONE
        )

    return datetime.now(
        timezone
    ).date()


# =========================================================
# РАССЧИТАТЬ ТЕКУЩУЮ СЕРИЮ ПРИВЫЧКИ
# =========================================================

def calculate_habit_streak(
    completed_dates: list[date],
    today: date,
) -> int:
    """
    Считает текущую серию конкретной привычки.

    Если привычка подтверждена сегодня,
    серия считается назад от сегодняшнего дня.

    Если сегодня ещё не подтверждена,
    серия считается назад от вчерашнего дня.
    Текущий незавершённый день серию не обрывает.
    """

    if not completed_dates:
        return 0

    completed_dates_set = set(
        completed_dates
    )

    if today in completed_dates_set:
        current_date = today
    else:
        current_date = (
            today - timedelta(days=1)
        )

    streak = 0

    while (
        current_date
        in completed_dates_set
    ):
        streak += 1

        current_date -= timedelta(
            days=1
        )

    return streak


# =========================================================
# РАССЧИТАТЬ МАКСИМАЛЬНУЮ СЕРИЮ ПРИВЫЧКИ
# =========================================================

def calculate_habit_max_streak(
    completed_dates: list[date],
) -> int:
    """
    Считает самую длинную серию привычки
    за всю историю подтверждений.
    """

    if not completed_dates:
        return 0

    unique_dates = sorted(
        set(completed_dates)
    )

    max_streak = 1
    current_streak = 1

    for index in range(
        1,
        len(unique_dates),
    ):
        previous_date = (
            unique_dates[index - 1]
        )

        current_date = (
            unique_dates[index]
        )

        if (
            current_date
            - previous_date
            == timedelta(days=1)
        ):
            current_streak += 1
        else:
            current_streak = 1

        max_streak = max(
            max_streak,
            current_streak,
        )

    return max_streak


# =========================================================
# РАССЧИТАТЬ ОБЩУЮ ТЕКУЩУЮ СЕРИЮ ПОЛЬЗОВАТЕЛЯ
# =========================================================

def calculate_user_streak(
    confirmation_dates: list[date],
    today: date,
) -> int:
    return calculate_user_streak_state(confirmation_dates, today)[0]

# =========================================================
# УСТАНОВИТЬ СОСТОЯНИЕ ПОДТВЕРЖДЕНИЯ
#
# is_confirmed=True  — подтвердить
# is_confirmed=False — отменить
#
# Повторный одинаковый запрос безопасен.
# =========================================================

async def set_habit_confirmation(
    user_id: int,
    habit_id: int,
    is_confirmed: bool,
    *,
    development_mode: bool = False,
) -> dict[str, Any] | None:
    async with get_connection() as connection:
        async with connection.transaction():
            await lock_league_week(connection)


            # -------------------------------------------------
            # Проверяем привычку.
            # -------------------------------------------------

            habit = await connection.fetchrow(
                """
                SELECT
                    id,
                    user_id,
                    xp_reward
                    , habit_type
                    , repeat_type, repeat_days, weekly_target, challenge_target, repeat_started_on
                FROM habits
                WHERE id = $1
                  AND user_id = $2
                  AND is_archived = FALSE
                FOR UPDATE
                """,
                habit_id,
                user_id,
            )

            if habit is None:
                return None

            # An ordinary habit endpoint cannot confirm research (and vice versa).
            if (habit["habit_type"] == "development") != development_mode:
                return None

            development_row = None
            if development_mode:
                # Habit row is already locked. Lock research in the same transaction,
                # before writing the confirmation or awarding any XP.
                development_row = await connection.fetchrow(
                    """SELECT * FROM development_progress
                       WHERE user_id=$1 AND habit_id=$2 FOR UPDATE""",
                    user_id, habit_id,
                )
                if development_row is None or development_row["completed_at"] is not None:
                    return None
                from backend.services.development.development_service import DAYS, sync_row
                from fastapi import HTTPException
                timezone_name_guard = await connection.fetchval(
                    "SELECT timezone FROM user_settings WHERE user_id=$1", user_id
                )
                research_today = get_user_local_date(timezone_name_guard)
                research_progress = await sync_row(connection, development_row, research_today)
                # reached_at is the irreversible completion marker. Once set,
                # neither confirmation nor cancellation is permitted, even if
                # legacy progress data is inconsistent with the target.
                if (development_row["reached_at"] is not None
                        or research_progress >= DAYS[development_row["cycle"] - 1]):
                    raise HTTPException(409, "Исследование завершено: подтверждения и отмена запрещены")

            # -------------------------------------------------
            # Часовой пояс пользователя.
            # -------------------------------------------------

            timezone_name = await connection.fetchval(
                """
                SELECT timezone
                FROM user_settings
                WHERE user_id = $1
                """,
                user_id,
            )

            confirmation_date = get_user_local_date(
                timezone_name
            )

            if is_confirmed and not is_confirmation_allowed(
                habit["repeat_type"], list(habit["repeat_days"] or []), confirmation_date
            ):
                raise ValueError("Сегодня привычка не запланирована")


            # -------------------------------------------------
            # Текущее подтверждение за сегодня.
            # -------------------------------------------------

            confirmation = await connection.fetchrow(
                """
                SELECT
                    id,
                    is_confirmed,
                    xp_awarded,
                    xp_amount,
                    xp_awarded_at
                FROM habit_confirmations
                WHERE habit_id = $1
                  AND confirmation_date = $2
                FOR UPDATE
                """,
                habit_id,
                confirmation_date,
            )

            confirmation_was_confirmed = bool(
                confirmation is not None
                and confirmation["is_confirmed"]
            )

            confirmation_state_changed = (
                confirmation_was_confirmed
                != bool(is_confirmed)
            )

            # Сколько XP реально будет снято именно этой отменой.
            # Ничего не угадываем на frontend: сервер знает,
            # было ли XP начислено этому подтверждению.
            xp_removed_today = (
                int(confirmation["xp_amount"] or 0)
                if (
                    not is_confirmed
                    and confirmation_was_confirmed
                    and confirmation["xp_awarded"]
                )
                else 0
            )

            # =================================================
            # ПОДТВЕРЖДЕНИЕ
            # =================================================

            if is_confirmed:
                if (
                    confirmation is not None
                    and confirmation["is_confirmed"]
                ):
                    pass

                else:
                    awarded_confirmations_today = (
                        await connection.fetchval(
                            """
                            SELECT COUNT(*)

                            FROM habit_confirmations AS hc

                            INNER JOIN habits AS h
                                ON h.id = hc.habit_id

                            WHERE h.user_id = $1
                              AND hc.confirmation_date = $2
                              AND hc.is_confirmed = TRUE
                              AND hc.xp_awarded = TRUE
                            """,
                            user_id,
                            confirmation_date,
                        )
                    )

                    should_award_xp = (
                        awarded_confirmations_today
                        < DAILY_XP_CONFIRMATIONS_LIMIT
                    )

                    xp_amount = (
                        int(habit["xp_reward"])
                        if should_award_xp
                        else 0
                    )

                    await connection.execute(
                        """
                        INSERT INTO habit_confirmations (
                            habit_id,
                            confirmation_date,
                            is_confirmed,
                            xp_awarded,
                            xp_amount,
                            xp_awarded_at
                        )
                        VALUES (
                            $1,
                            $2,
                            TRUE,
                            $3,
                            $4,
                            CASE WHEN $3 THEN clock_timestamp() ELSE NULL END
                        )

                        ON CONFLICT (
                            habit_id,
                            confirmation_date
                        )
                        DO UPDATE SET
                            is_confirmed = TRUE,
                            xp_awarded =
                                EXCLUDED.xp_awarded,
                            xp_amount =
                                EXCLUDED.xp_amount,
                            xp_awarded_at = EXCLUDED.xp_awarded_at,
                            updated_at = NOW()
                        """,
                        habit_id,
                        confirmation_date,
                        should_award_xp,
                        xp_amount,
                    )

            # =================================================
            # ОТМЕНА ПОДТВЕРЖДЕНИЯ
            # =================================================

            else:
                if confirmation is not None:
                    await connection.execute(
                        """
                        UPDATE habit_confirmations
                        SET
                            is_confirmed = FALSE,
                            xp_awarded = FALSE,
                            xp_amount = 0,
                            xp_awarded_at = NULL,
                            updated_at = NOW()
                        WHERE id = $1
                        """,
                        confirmation["id"],
                    )

            # =================================================
            # ОБЩАЯ СТАТИСТИКА
            #
            # Раньше после КАЖДОГО клика заново считались:
            # - все подтверждения пользователя;
            # - весь XP привычек;
            # - весь referral XP;
            # - весь achievement XP.
            #
            # Теперь для существующей user_stats меняем только
            # то, что реально изменилось этим кликом.
            #
            # Полный старый пересчёт оставлен только как безопасный
            # fallback, если строки user_stats почему-то ещё нет.
            # =================================================

            current_stats = await connection.fetchrow(
                """
                SELECT
                    max_streak,
                    total_confirmations,
                    total_xp
                FROM user_stats
                WHERE user_id = $1
                FOR UPDATE
                """,
                user_id,
            )

            if current_stats is not None:
                confirmation_delta = 0
                xp_delta = 0

                if confirmation_state_changed:
                    if is_confirmed:
                        confirmation_delta = 1

                        # После INSERT/UPDATE это точное количество XP,
                        # начисленное именно текущим подтверждением.
                        current_confirmation_xp = await connection.fetchval(
                            """
                            SELECT
                                CASE
                                    WHEN is_confirmed = TRUE
                                     AND xp_awarded = TRUE
                                    THEN xp_amount
                                    ELSE 0
                                END
                            FROM habit_confirmations
                            WHERE habit_id = $1
                              AND confirmation_date = $2
                            """,
                            habit_id,
                            confirmation_date,
                        )

                        xp_delta = int(
                            current_confirmation_xp
                            or 0
                        )
                    else:
                        confirmation_delta = -1
                        xp_delta = -int(
                            xp_removed_today
                            or 0
                        )

                total_confirmations = max(
                    0,
                    int(
                        current_stats[
                            "total_confirmations"
                        ]
                        or 0
                    )
                    + confirmation_delta,
                )

                total_xp = max(
                    0,
                    int(
                        current_stats[
                            "total_xp"
                        ]
                        or 0
                    )
                    + xp_delta,
                )

                previous_max_streak = int(
                    current_stats[
                        "max_streak"
                    ]
                    or 0
                )

            else:
                # Редкий защитный сценарий для старой/неполной БД:
                # если user_stats отсутствует, один раз считаем всё
                # старым надёжным способом.
                statistics = await connection.fetchrow(
                    """
                    SELECT
                        (
                            SELECT
                                COUNT(*)::INTEGER
                            FROM habit_confirmations AS hc
                            INNER JOIN habits AS h
                                ON h.id = hc.habit_id
                            WHERE h.user_id = $1
                              AND hc.is_confirmed = TRUE
                        ) AS total_confirmations,

                        (
                            COALESCE(
                                (
                                    SELECT SUM(hc.xp_amount)
                                    FROM habit_confirmations AS hc
                                    INNER JOIN habits AS h
                                        ON h.id = hc.habit_id
                                    WHERE h.user_id = $1
                                      AND hc.is_confirmed = TRUE
                                      AND hc.xp_awarded = TRUE
                                ),
                                0
                            )
                            +
                            COALESCE(
                                (
                                    SELECT SUM(r.xp_amount)
                                    FROM referrals AS r
                                    WHERE r.inviter_user_id = $1
                                      AND r.xp_awarded = TRUE
                                ),
                                0
                            )
                            +
                            COALESCE(
                                (
                                    SELECT SUM(ua.xp_amount)
                                    FROM user_achievements AS ua
                                    WHERE ua.user_id = $1
                                      AND ua.xp_awarded = TRUE
                                ),
                                0
                            )
                        )::INTEGER AS total_xp
                    """,
                    user_id,
                )

                total_confirmations = int(
                    statistics[
                        "total_confirmations"
                    ]
                    if statistics
                    else 0
                )

                total_xp = int(
                    statistics[
                        "total_xp"
                    ]
                    if statistics
                    else 0
                )

                previous_max_streak = 0

            # =================================================
            # ОБЩИЙ СТРИК
            # =================================================

            user_confirmation_rows = (
                await connection.fetch(
                    """
                    SELECT DISTINCT
                        hc.confirmation_date

                    FROM habit_confirmations AS hc

                    INNER JOIN habits AS h
                        ON h.id = hc.habit_id

                    WHERE h.user_id = $1
                      AND hc.is_confirmed = TRUE

                    ORDER BY
                        hc.confirmation_date ASC
                    """,
                    user_id,
                )
            )

            user_confirmation_dates = [
                row["confirmation_date"]
                for row in user_confirmation_rows
            ]

            current_streak, current_streak_frozen = calculate_user_streak_state(
                user_confirmation_dates, confirmation_date
            )

            # =================================================
            # ДРУЖЕСКИЙ СТРИК
            #
            # Если подтверждение относится к shared-привычке, результат дня
            # мог измениться сразу для всей группы. Поэтому синхронизируем
            # дружеский streak всех активных участников этой группы.
            # =================================================

            shared_user_rows = await connection.fetch(
                """
                SELECT DISTINCT member.user_id
                FROM shared_habit_members me
                JOIN shared_habit_members member
                  ON member.shared_habit_id = me.shared_habit_id
                 AND member.left_at IS NULL
                WHERE me.habit_id = $1
                  AND me.left_at IS NULL
                """,
                habit_id,
            )

            # Дружеский стрик относится только к совместным привычкам.
            # Для обычной привычки не запускаем тяжёлый пересчёт shared-истории.
            if shared_user_rows:
                affected_friend_user_ids = [
                    int(row["user_id"])
                    for row in shared_user_rows
                ]

                friends_states = await update_friends_streak_for_users(
                    affected_friend_user_ids,
                    confirmation_date,
                    connection,
                )

                own_friends_state = friends_states.get(
                    user_id,
                    {
                        "friends_streak": 0,
                        "friends_streak_frozen": False,
                        "friends_max_streak": 0,
                    },
                )
            else:
                own_friends_row = await connection.fetchrow(
                    """
                    SELECT
                        friends_streak,
                        friends_max_streak
                    FROM user_stats
                    WHERE user_id = $1
                    """,
                    user_id,
                )

                own_friends_state = {
                    "friends_streak":
                        int(own_friends_row["friends_streak"] or 0)
                        if own_friends_row
                        else 0,

                    "friends_streak_frozen":
                        False,

                    "friends_max_streak":
                        int(own_friends_row["friends_max_streak"] or 0)
                        if own_friends_row
                        else 0,
                }

            max_streak = max(
                int(previous_max_streak or 0),
                current_streak,
            )

            # =================================================
            # ОБНОВЛЯЕМ USER_STATS
            # =================================================

            await connection.execute(
                """
                INSERT INTO user_stats (
                    user_id,
                    current_streak,
                    max_streak,
                    total_confirmations,
                    total_xp
                )
                VALUES (
                    $1,
                    $2,
                    $3,
                    $4,
                    $5
                )

                ON CONFLICT (user_id)
                DO UPDATE SET
                    current_streak =
                        EXCLUDED.current_streak,

                    max_streak =
                        GREATEST(
                            user_stats.max_streak,
                            EXCLUDED.max_streak
                        ),

                    total_confirmations =
                        EXCLUDED.total_confirmations,

                    total_xp =
                        EXCLUDED.total_xp,

                    updated_at = NOW()
                """,
                user_id,
                current_streak,
                max_streak,
                total_confirmations,
                total_xp,
            )

            # Недельный рейтинг; общий XP уже обновлён выше.
            await refresh_user_weekly_xp(connection, user_id)
            # A cancellation must also update the week that received the award.
            if (not is_confirmed and confirmation is not None
                    and confirmation["xp_awarded"] and confirmation["xp_awarded_at"]):
                await refresh_user_weekly_xp(
                    connection, user_id, at=confirmation["xp_awarded_at"]
                )

            # =================================================
            # ФИНАЛЬНОЕ СОСТОЯНИЕ ПОДТВЕРЖДЕНИЯ
            # =================================================

            final_confirmation = await connection.fetchrow(
                """
                SELECT
                    is_confirmed,
                    xp_awarded,
                    xp_amount
                FROM habit_confirmations
                WHERE habit_id = $1
                  AND confirmation_date = $2
                """,
                habit_id,
                confirmation_date,
            )

            completed_today = bool(
                final_confirmation
                and final_confirmation[
                    "is_confirmed"
                ]
            )

            xp_awarded_today = bool(
                final_confirmation
                and final_confirmation[
                    "is_confirmed"
                ]
                and final_confirmation[
                    "xp_awarded"
                ]
            )

            xp_amount_today = (
                int(
                    final_confirmation[
                        "xp_amount"
                    ]
                )
                if xp_awarded_today
                else 0
            )

            # =================================================
            # ДАТЫ ПОДТВЕРЖДЕНИЙ ПРИВЫЧКИ
            # =================================================

            completed_date_rows = await connection.fetch(
                """
                SELECT
                    confirmation_date
                FROM habit_confirmations
                WHERE habit_id = $1
                  AND is_confirmed = TRUE
                ORDER BY confirmation_date ASC
                """,
                habit_id,
            )

            habit_completed_dates = [
                row["confirmation_date"]
                for row in completed_date_rows
            ]

            # =================================================
            # СТРИК ПРИВЫЧКИ
            # =================================================

            from backend.services.habits.repeat_rules import calculate_repeat_streak_state
            habit_streak, habit_streak_frozen = calculate_repeat_streak_state(
                habit["repeat_type"], list(habit["repeat_days"] or []),
                habit_completed_dates, confirmation_date, habit["repeat_started_on"],
            )
            shared_state = (await get_shared_streak_states_for_habits([habit_id], confirmation_date, connection=connection)).get(habit_id)
            if shared_state:
                habit_streak = int(shared_state["streak"])
                habit_streak_frozen = bool(shared_state["frozen"])

            habit_max_streak = (
                calculate_habit_max_streak(
                    completed_dates=
                        habit_completed_dates,
                )
            )

            habit_completed_count = len(
                habit_completed_dates
            )

            # =================================================
            # НЕДЕЛЬНЫЙ ПРОГРЕСС
            # =================================================

            week_start = (
                confirmation_date
                - timedelta(
                    days=
                        confirmation_date.weekday()
                )
            )

            habit_week_progress = [
                False,
                False,
                False,
                False,
                False,
                False,
                False,
            ]

            for completed_date in (
                habit_completed_dates
            ):
                day_index = (
                    completed_date
                    - week_start
                ).days

                if 0 <= day_index <= 6:
                    habit_week_progress[
                        day_index
                    ] = True

            # =================================================
            # RESPONSE
            # =================================================

            if development_mode:
                # Confirmation, research progress and XP are committed together.
                development_row = await connection.fetchrow(
                    "SELECT * FROM development_progress WHERE user_id=$1 AND habit_id=$2",
                    user_id, habit_id,
                )
                await sync_row(connection, development_row, confirmation_date)

            return {
                "habit": {
                    "id":
                        habit_id,

                    "completed_today":
                        completed_today,

                    "completed_dates": [
                        completed_date.isoformat()
                        for completed_date
                        in habit_completed_dates
                    ],

                    "streak":
                        habit_streak,

                    "streak_frozen":
                        habit_streak_frozen,

                    "max_streak":
                        habit_max_streak,

                    "completed_count":
                        habit_completed_count,

                    "week_progress":
                        habit_week_progress,

                    "xp_awarded_today":
                        xp_awarded_today,

                    "xp_amount_today":
                        xp_amount_today,

                    "xp_removed_today":
                        xp_removed_today,

                    "confirmation_date":
                        confirmation_date.isoformat(),

                    "confirmation_allowed_today":
                        is_confirmation_allowed(
                            habit["repeat_type"], list(habit["repeat_days"] or []), confirmation_date
                        ),
                },

                "confirmation_state_changed":
                    confirmation_state_changed,

                "statistics": {
                    "current_streak":
                        current_streak,

                    "current_streak_frozen":
                        current_streak_frozen,

                    "max_streak":
                        max_streak,

                    "friends_streak":
                        own_friends_state["friends_streak"],

                    "friends_streak_frozen":
                        own_friends_state["friends_streak_frozen"],

                    "friends_max_streak":
                        own_friends_state["friends_max_streak"],

                    "total_confirmations":
                        total_confirmations,

                    "total_xp":
                        total_xp,
                },
            }
