import logging
import re
from datetime import time
from typing import Literal

from fastapi import (
    APIRouter,
    HTTPException,
    status,
)

from backend.database.database import get_connection

async def reject_development_habit(user_id, habit_id):
    async with get_connection() as conn:
        found=await conn.fetchval("SELECT 1 FROM habits WHERE user_id=$1 AND id=$2 AND habit_type='development'",user_id,habit_id)
    if found:
        raise HTTPException(status_code=409,detail="Используйте раздел Развитие для управления исследованием")

from backend.api.dependencies import (
    CurrentUser,
)

from pydantic import BaseModel, Field

from backend.repositories.habits import (
    create_habit,
    get_user_habits,
)

from backend.repositories.habits.shared_habits_repository import (
    get_shared_invite_preview,
    join_shared_habit,
)

from backend.services.habits.habit_service import (
    archive_user_habit,
    edit_habit,
    get_user_archived_habits,
    restore_user_habit,
    update_habit_confirmation,
)

from backend.services.habits.shared_habit_notification_service import (
    send_shared_habit_join_notification,
)

from backend.services.habits.repeat_rules import (
    normalize_repeat_rule,
)


# Используем логгер Uvicorn, чтобы сообщения гарантированно
# попадали в существующий файл api.log.
logger = logging.getLogger(
    "uvicorn.error"
)


router = APIRouter(
    prefix="/api/habits",
    tags=["habits"],
)


# =========================================================
# СХЕМЫ ЗАПРОСОВ
# =========================================================

class HabitCreateRequest(BaseModel):
    title: str = Field(
        min_length=1,
        max_length=60,
    )

    description: str | None = Field(default=None, max_length=200)

    emoji: str = Field(
        default="✱",
        min_length=1,
        max_length=20,
    )

    color: str = Field(
        default="blue",
        min_length=1,
        max_length=30,
    )

    size: Literal["large", "small"] = "large"
    repeat_type: Literal["days", "challenge"] = "days"
    repeat_days: list[int] = Field(default_factory=lambda: [1, 2, 3, 4, 5, 6, 7])
    weekly_target: int | None = None
    challenge_target: int | None = None
    habit_reminder: str | None = None


class HabitUpdateRequest(BaseModel):
    title: str = Field(
        min_length=1,
        max_length=60,
    )

    description: str | None = Field(default=None, max_length=200)

    emoji: str = Field(
        default="✱",
        min_length=1,
        max_length=20,
    )

    color: str = Field(
        default="blue",
        min_length=1,
        max_length=30,
    )

    size: Literal["large", "small"] = "large"
    repeat_type: Literal["days", "challenge"] = "days"
    repeat_days: list[int] = Field(default_factory=lambda: [1, 2, 3, 4, 5, 6, 7])
    weekly_target: int | None = None
    challenge_target: int | None = None
    habit_reminder: str | None = None


class HabitConfirmationRequest(BaseModel):
    is_confirmed: bool


def normalize_habit_reminder(value: str | None) -> time | None:
    if value is None:
        return None

    normalized = str(value).strip()
    if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", normalized):
        raise ValueError("Некорректное время напоминания")

    return time.fromisoformat(normalized)


# =========================================================
# ПОЛУЧИТЬ АКТИВНЫЕ ПРИВЫЧКИ
# =========================================================

@router.get("")
async def read_habits(
    user: CurrentUser,
):
    result = await get_user_habits(
        user["id"]
    )

    return result


# =========================================================
# ПОЛУЧИТЬ АРХИВНЫЕ ПРИВЫЧКИ
# =========================================================

@router.get("/archived")
async def read_archived_habits(
    user: CurrentUser,
):
    """
    Возвращает архивные привычки пользователя.

    Архив не загружается через bootstrap.
    Этот endpoint вызывается только тогда,
    когда пользователь впервые открывает
    страницу Архива привычек.
    """

    try:
        habits = (
            await get_user_archived_habits(
                user_id=user["id"],
            )
        )

        return {
            "habits": habits,
        }

    except Exception:
        logger.exception(
            "\n"
            "==================================================\n"
            "Ошибка при получении архива привычек\n\n"
            "Пользователь : %s\n"
            "==================================================",
            user["id"],
        )

        raise


# =========================================================
# СОЗДАТЬ ПРИВЫЧКУ
#
# Создание сейчас не логируем,
# потому что пользователь просил логировать только:
# - подтверждение;
# - отмену подтверждения;
# - редактирование;
# - архивирование;
# - восстановление;
# - ошибки этих операций.
# =========================================================

@router.post(
    "",
    status_code=status.HTTP_201_CREATED,
)
async def add_habit(
    payload: HabitCreateRequest,

    user: CurrentUser,
):
    try:
        repeat_type, repeat_days, weekly_target, challenge_target = normalize_repeat_rule(
            payload.repeat_type, payload.repeat_days, payload.weekly_target, payload.challenge_target
        )
        habit_reminder = normalize_habit_reminder(payload.habit_reminder)
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    habit = await create_habit(
        user_id=user["id"],
        title=payload.title.strip(),
        description=(payload.description.strip() or None) if payload.description else None,
        emoji=payload.emoji,
        color=payload.color,
        size=payload.size,
        repeat_type=repeat_type,
        repeat_days=repeat_days,
        weekly_target=weekly_target,
        challenge_target=challenge_target,
        habit_reminder=habit_reminder,
    )

    return {
        "habit": habit,
    }


# =========================================================
# ПРИГЛАШЕНИЕ В СОВМЕСТНУЮ ПРИВЫЧКУ
# =========================================================

@router.get("/invite/{invite_token}")
async def read_shared_habit_invite(invite_token: str, user: CurrentUser):
    invite = await get_shared_invite_preview(invite_token, user["id"])
    if invite is None:
        raise HTTPException(status_code=404, detail="Приглашение не найдено")
    return {"invite": invite}


@router.post("/invite/{invite_token}/join")
async def join_shared_habit_endpoint(invite_token: str, user: CurrentUser):
    result = await join_shared_habit(invite_token, user["id"])
    if result is None:
        raise HTTPException(status_code=404, detail="Приглашение не найдено")
    if result.get("status") == "full":
        raise HTTPException(status_code=409, detail="В совместной привычке уже 5 участников")
    if result.get("status") == "joined":
        try:
            await send_shared_habit_join_notification(
                int(result["shared_habit_id"]), int(user["id"])
            )
        except Exception:
            logger.exception("Failed to notify owner about shared habit join")
    return result


# =========================================================
# РЕДАКТИРОВАТЬ ПРИВЫЧКУ
# =========================================================

@router.patch("/{habit_id}")
async def update_existing_habit(
    habit_id: int,
    payload: HabitUpdateRequest,

    user: CurrentUser,
):
    await reject_development_habit(user["id"],habit_id)

    try:
        repeat_type, repeat_days, weekly_target, challenge_target = normalize_repeat_rule(
            payload.repeat_type, payload.repeat_days, payload.weekly_target, payload.challenge_target
        )
        habit = await edit_habit(
            user_id=user["id"],
            habit_id=habit_id,
            title=payload.title.strip(),
        description=(payload.description.strip() or None) if payload.description else None,
            emoji=payload.emoji,
            color=payload.color,
            size=payload.size,
            repeat_type=repeat_type,
            repeat_days=repeat_days,
            weekly_target=weekly_target,
            challenge_target=challenge_target,
            habit_reminder=normalize_habit_reminder(payload.habit_reminder),
        )

        if habit is None:
            logger.warning(
                "\n"
                "==================================================\n"
                "Попытка отредактировать несуществующую привычку\n\n"
                "Пользователь : %s\n"
                "Привычка     : %s\n"
                "==================================================",
                user["id"],
                habit_id,
            )

            raise HTTPException(
                status_code=
                    status.HTTP_404_NOT_FOUND,

                detail=
                    "Привычка не найдена",
            )

        logger.info(
            "\n"
            "==================================================\n"
            "Пользователь отредактировал привычку\n\n"
            "Пользователь : %s\n"
            "Привычка     : %s\n"
            "==================================================",
            user["id"],
            habit_id,
        )

        return {
            "habit": habit,
        }

    except HTTPException:
        raise

    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    except Exception:
        logger.exception(
            "\n"
            "==================================================\n"
            "Ошибка при редактировании привычки\n\n"
            "Пользователь : %s\n"
            "Привычка     : %s\n"
            "==================================================",
            user["id"],
            habit_id,
        )

        raise


# =========================================================
# АРХИВИРОВАТЬ ПРИВЫЧКУ
# =========================================================

@router.patch("/{habit_id}/archive")
async def archive_habit_endpoint(
    habit_id: int,

    user: CurrentUser,
):
    await reject_development_habit(user["id"],habit_id)

    try:
        archived = await archive_user_habit(
            user_id=user["id"],
            habit_id=habit_id,
        )

        if not archived:
            logger.warning(
                "\n"
                "==================================================\n"
                "Попытка архивировать несуществующую привычку\n\n"
                "Пользователь : %s\n"
                "Привычка     : %s\n"
                "==================================================",
                user["id"],
                habit_id,
            )

            raise HTTPException(
                status_code=
                    status.HTTP_404_NOT_FOUND,

                detail=
                    "Привычка не найдена",
            )

        logger.info(
            "\n"
            "==================================================\n"
            "Пользователь архивировал привычку\n\n"
            "Пользователь : %s\n"
            "Привычка     : %s\n"
            "==================================================",
            user["id"],
            habit_id,
        )

        return {
            "success": True,
            "habit_id": habit_id,
        }

    except HTTPException:
        raise

    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except Exception:
        logger.exception(
            "\n"
            "==================================================\n"
            "Ошибка при архивировании привычки\n\n"
            "Пользователь : %s\n"
            "Привычка     : %s\n"
            "==================================================",
            user["id"],
            habit_id,
        )

        raise


# =========================================================
# ВОССТАНОВИТЬ ПРИВЫЧКУ ИЗ АРХИВА
# =========================================================

@router.post("/{habit_id}/restore")
async def restore_habit_endpoint(
    habit_id: int,

    user: CurrentUser,
):
    """
    Возвращает архивную привычку
    обратно в список активных.

    История подтверждений,
    XP и лучший стрик сохраняются.
    """

    await reject_development_habit(user["id"],habit_id)

    try:
        habit = await restore_user_habit(
            user_id=user["id"],
            habit_id=habit_id,
        )

        if habit is None:
            logger.warning(
                "\n"
                "==================================================\n"
                "Попытка восстановить несуществующую "
                "или активную привычку\n\n"
                "Пользователь : %s\n"
                "Привычка     : %s\n"
                "==================================================",
                user["id"],
                habit_id,
            )

            raise HTTPException(
                status_code=
                    status.HTTP_404_NOT_FOUND,

                detail=
                    "Архивная привычка не найдена",
            )

        logger.info(
            "\n"
            "==================================================\n"
            "Пользователь восстановил привычку из архива\n\n"
            "Пользователь : %s\n"
            "Привычка     : %s\n"
            "==================================================",
            user["id"],
            habit_id,
        )

        return {
            "success": True,
            "habit": habit,
        }

    except HTTPException:
        raise

    except Exception:
        logger.exception(
            "\n"
            "==================================================\n"
            "Ошибка при восстановлении привычки из архива\n\n"
            "Пользователь : %s\n"
            "Привычка     : %s\n"
            "==================================================",
            user["id"],
            habit_id,
        )

        raise


# =========================================================
# ПОДТВЕРДИТЬ ИЛИ ОТМЕНИТЬ ПОДТВЕРЖДЕНИЕ
# =========================================================

@router.put("/{habit_id}/confirmation")
async def set_confirmation(
    habit_id: int,
    payload: HabitConfirmationRequest,

    user: CurrentUser,
):
    await reject_development_habit(user["id"],habit_id)

    try:
        result = (
            await update_habit_confirmation(
                user_id=user["id"],
                habit_id=habit_id,
                is_confirmed=
                    payload.is_confirmed,
            )
        )

        if result is None:
            action_text = (
                "подтвердить"
                if payload.is_confirmed
                else
                "отменить подтверждение"
            )

            logger.warning(
                "\n"
                "==================================================\n"
                "Попытка %s несуществующей привычки\n\n"
                "Пользователь : %s\n"
                "Привычка     : %s\n"
                "==================================================",
                action_text,
                user["id"],
                habit_id,
            )

            raise HTTPException(
                status_code=
                    status.HTTP_404_NOT_FOUND,

                detail=
                    "Привычка не найдена",
            )

        habit_result = result.get(
            "habit",
            {},
        )

        confirmation_date = (
            habit_result.get(
                "confirmation_date"
            )
        )

        xp_awarded = bool(
            habit_result.get(
                "xp_awarded_today"
            )
        )

        xp_amount = (
            habit_result.get(
                "xp_amount_today",
                0,
            )
        )

        if payload.is_confirmed:
            logger.info(
                "\n"
                "==================================================\n"
                "Пользователь подтвердил привычку\n\n"
                "Пользователь : %s\n"
                "Привычка     : %s\n"
                "Дата         : %s\n"
                "XP начислено : %s\n"
                "XP           : %s\n"
                "==================================================",
                user["id"],
                habit_id,
                confirmation_date,
                "Да" if xp_awarded else "Нет",
                xp_amount,
            )

        else:
            logger.info(
                "\n"
                "==================================================\n"
                "Пользователь отменил подтверждение привычки\n\n"
                "Пользователь : %s\n"
                "Привычка     : %s\n"
                "Дата         : %s\n"
                "==================================================",
                user["id"],
                habit_id,
                confirmation_date,
            )

        return result

    except HTTPException:
        raise

    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error

    except Exception:
        if payload.is_confirmed:
            error_title = (
                "Ошибка при подтверждении привычки"
            )
        else:
            error_title = (
                "Ошибка при отмене подтверждения привычки"
            )

        logger.exception(
            "\n"
            "==================================================\n"
            "%s\n\n"
            "Пользователь : %s\n"
            "Привычка     : %s\n"
            "==================================================",
            error_title,
            user["id"],
            habit_id,
        )

        raise
