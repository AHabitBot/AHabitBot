import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from backend.admin.routes import router as admin_router
from fastapi.middleware.cors import (
    CORSMiddleware,
)

from backend.api.habits import (
    router as habits_router,
)

from backend.api.bootstrap import (
    router as bootstrap_router,
)

from backend.database.database import (
    close_db,
    connect_db,
)

from backend.api.leaderboard_status import router as leaderboard_status_router

from backend.api.leaderboard import (
    router as leaderboard_router,
)

from backend.api.follows import router as follows_router

from backend.api.profile import (
    router as profile_router,
)

from backend.api.settings import (
    router as settings_router,
)

from backend.services.leaderboard.league_week_scheduler import run_league_week_loop

from backend.services.habits.shared_habit_notification_service import (
    run_shared_habit_freeze_loop,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_db()
    shared_freeze_task = asyncio.create_task(
        run_shared_habit_freeze_loop()
    )

    league_task = asyncio.create_task(run_league_week_loop())

    try:
        yield
    finally:
        league_task.cancel()
        try:
            await league_task
        except asyncio.CancelledError:
            pass
        shared_freeze_task.cancel()
        try:
            await shared_freeze_task
        except asyncio.CancelledError:
            pass
        await close_db()


app = FastAPI(
    title="AHabit API",
    version="1.0.0",
    lifespan=lifespan,
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://ahabit.org",
        "https://www.ahabit.org",
        "https://ahabitbot.vercel.app",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(admin_router)

app.include_router(
    bootstrap_router
)

app.include_router(
    habits_router
)

app.include_router(
    leaderboard_router
)
app.include_router(leaderboard_status_router)

app.include_router(
    profile_router
)
app.include_router(follows_router)

app.include_router(
    settings_router
)


@app.get("/health")
async def health_check():
    return {
        "status": "ok",
    }